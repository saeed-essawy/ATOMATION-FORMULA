
# App Bundle (manifest)

This folder contains `app.json` for your monday app integration.

Current URLs point to:
https://your-app.vercel.app/api/subscribe
https://your-app.vercel.app/api/unsubscribe
https://your-app.vercel.app/api/event
https://your-app.vercel.app/api/execute

After you deploy the server on Vercel, replace `https://your-app.vercel.app` with your real domain
(e.g., `https://formula-sync-123.vercel.app`) and re-upload this bundle as a new App Version.
